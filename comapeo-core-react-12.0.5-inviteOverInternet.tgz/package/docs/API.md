## Functions

- [ClientApiProvider](#clientapiprovider)
- [useClientApi](#useclientapi)
- [useOwnDeviceInfo](#useowndeviceinfo)
- [useIsArchiveDevice](#useisarchivedevice)
- [useSetOwnDeviceInfo](#usesetowndeviceinfo)
- [useSetIsArchiveDevice](#usesetisarchivedevice)
- [ReceivedMapSharesProvider](#receivedmapsharesprovider)
- [SentMapSharesProvider](#sentmapsharesprovider)
- [useReceivedMapSharesActions](#usereceivedmapsharesactions)
- [useReceivedMapSharesState](#usereceivedmapsharesstate)
- [useReceivedMapSharesState](#usereceivedmapsharesstate)
- [useReceivedMapSharesState](#usereceivedmapsharesstate)
- [useSentMapSharesActions](#usesentmapsharesactions)
- [useSentMapSharesState](#usesentmapsharesstate)
- [createMapServerApi](#createmapserverapi)
- [MapServerProvider](#mapserverprovider)
- [useMapServerApi](#usemapserverapi)
- [ComapeoCoreProvider](#comapeocoreprovider)
- [useProjectSettings](#useprojectsettings)
- [useSingleProject](#usesingleproject)
- [useManyProjects](#usemanyprojects)
- [useSingleMember](#usesinglemember)
- [useManyMembers](#usemanymembers)
- [useIconUrl](#useiconurl)
- [useAttachmentUrl](#useattachmenturl)
- [useDocumentCreatedBy](#usedocumentcreatedby)
- [useOwnRoleInProject](#useownroleinproject)
- [useAddServerPeer](#useaddserverpeer)
- [useRemoveServerPeer](#useremoveserverpeer)
- [useCreateProject](#usecreateproject)
- [useLeaveProject](#useleaveproject)
- [useImportProjectCategories](#useimportprojectcategories)
- [useImportProjectConfig](#useimportprojectconfig)
- [useUpdateProjectSettings](#useupdateprojectsettings)
- [useChangeMemberRole](#usechangememberrole)
- [useRemoveMember](#useremovemember)
- [useProjectOwnRoleChangeListener](#useprojectownrolechangelistener)
- [useCreateBlob](#usecreateblob)
- [useSyncState](#usesyncstate)
- [useDataSyncProgress](#usedatasyncprogress)
- [useStartSync](#usestartsync)
- [useStopSync](#usestopsync)
- [useConnectSyncServers](#useconnectsyncservers)
- [useDisconnectSyncServers](#usedisconnectsyncservers)
- [useSetAutostopDataSyncTimeout](#usesetautostopdatasynctimeout)
- [useExportGeoJSON](#useexportgeojson)
- [useExportZipFile](#useexportzipfile)
- [useManyInviteLinks](#usemanyinvitelinks)
- [useCreateInviteLink](#usecreateinvitelink)
- [useCancelInviteLink](#usecancelinvitelink)
- [useAcceptInviteLinkRequest](#useacceptinvitelinkrequest)
- [useDenyInviteLinkRequest](#usedenyinvitelinkrequest)
- [useSingleDocByDocId](#usesingledocbydocid)
- [useSingleDocByVersionId](#usesingledocbyversionid)
- [useManyDocs](#usemanydocs)
- [useCreateDocument](#usecreatedocument)
- [useUpdateDocument](#useupdatedocument)
- [useDeleteDocument](#usedeletedocument)
- [usePresetsSelection](#usepresetsselection)
- [useManyInvites](#usemanyinvites)
- [useSingleInvite](#usesingleinvite)
- [useAcceptInvite](#useacceptinvite)
- [useRejectInvite](#userejectinvite)
- [useSendInvite](#usesendinvite)
- [useRequestCancelInvite](#userequestcancelinvite)
- [useManyJoinRequests](#usemanyjoinrequests)
- [useSingleJoinRequest](#usesinglejoinrequest)
- [useCreateJoinRequest](#usecreatejoinrequest)
- [useCancelJoinRequest](#usecanceljoinrequest)
- [useMapStyleUrl](#usemapstyleurl)
- [useImportCustomMapFile](#useimportcustommapfile)
- [useRemoveCustomMapFile](#useremovecustommapfile)
- [useGetCustomMapInfo](#usegetcustommapinfo)
- [useManyReceivedMapShares](#usemanyreceivedmapshares)
- [useSingleReceivedMapShare](#usesinglereceivedmapshare)
- [useDownloadReceivedMapShare](#usedownloadreceivedmapshare)
- [useDeclineReceivedMapShare](#usedeclinereceivedmapshare)
- [useAbortReceivedMapShareDownload](#useabortreceivedmapsharedownload)
- [useSendMapShare](#usesendmapshare)
- [useCancelSentMapShare](#usecancelsentmapshare)
- [useSingleSentMapShare](#usesinglesentmapshare)

### ClientApiProvider

Create a context provider that holds a CoMapeo API client instance.

| Function | Type |
| ---------- | ---------- |
| `ClientApiProvider` | `({ children, clientApi, }: ClientApiProviderProps) => Element` |

Parameters:

* `opts.children`: React children node
* `opts.clientApi`: Client API instance


### useClientApi

Access a client API instance. If a ClientApiContext provider is not
set up, it will throw an error.

| Function | Type |
| ---------- | ---------- |
| `useClientApi` | `() => ComapeoCoreClientApi` |

Returns:

Client API instance

Examples:

```tsx
function ClientExample() {
  return (
    // Creation of clientApi omitted for brevity
    <ClientApiContext.Provider clientApi={clientApi}>
      <ComponentThatUsesClient />
    </ClientApiContext.Provider>
  )
}

function ComponentThatUsesClient() {
  const clientApi = useClientApi()

  // Rest omitted for brevity.
}
```


### useOwnDeviceInfo

Retrieve info about the current device.

| Function | Type |
| ---------- | ---------- |
| `useOwnDeviceInfo` | `() => Pick<UseSuspenseQueryResult<{ deviceId: string; deviceType: "device_type_unspecified" or "mobile" or "tablet" or "desktop" or "selfHostedServer" or "UNRECOGNIZED"; } and Partial<DeviceInfoParam>>, "data" or ... 1 more ... or "isRefetching">` |

Examples:

```tsx
function DeviceInfoExample() {
  const { data } = useDeviceInfo()
}
```


### useIsArchiveDevice

Retrieve whether the current device is an archive device or not.

| Function | Type |
| ---------- | ---------- |
| `useIsArchiveDevice` | `() => { data: boolean; error: Error or null; isRefetching: boolean; }` |

Examples:

```tsx
function IsArchiveDeviceExample() {
  const { data } = useIsArchiveDevice()
}
```


### useSetOwnDeviceInfo

Update the device info for the current device.

| Function | Type |
| ---------- | ---------- |
| `useSetOwnDeviceInfo` | `() => Pick<Override<MutationObserverIdleResult<void, Error, { name: string; deviceType: "device_type_unspecified" or "mobile" or "tablet" or "desktop" or "selfHostedServer" or "UNRECOGNIZED"; }, unknown>, { ...; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useSetIsArchiveDevice

Set or unset the current device as an archive device.

| Function | Type |
| ---------- | ---------- |
| `useSetIsArchiveDevice` | `() => Pick<Override<MutationObserverIdleResult<void, Error, { isArchiveDevice: boolean; }, unknown>, { mutate: UseMutateFunction<void, Error, { isArchiveDevice: boolean; }, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### ReceivedMapSharesProvider

| Function | Type |
| ---------- | ---------- |
| `ReceivedMapSharesProvider` | `({ children, clientApi, mapServerApi, queryClient, }: { clientApi: ComapeoCoreClientApi; mapServerApi: MapServerApi; } and { children?: ReactNode; } and { queryClient: QueryClient; }) => Element` |

### SentMapSharesProvider

| Function | Type |
| ---------- | ---------- |
| `SentMapSharesProvider` | `({ children, clientApi, mapServerApi, }: MapSharesProviderProps) => Element` |

### useReceivedMapSharesActions

| Function | Type |
| ---------- | ---------- |
| `useReceivedMapSharesActions` | `() => { download({ shareId }: DownloadMapShareOptions): Promise<void>; decline({ shareId, reason }: DeclineMapShareOptions): Promise<void>; abort({ shareId }: AbortMapShareOptions): Promise<...>; }` |

### useReceivedMapSharesState

| Function | Type |
| ---------- | ---------- |
| `useReceivedMapSharesState` | `{ (): ReceivedMapShareState[]; <T>(selector: (state: ReceivedMapShareState[]) => T): T; }` |

### useReceivedMapSharesState

| Function | Type |
| ---------- | ---------- |
| `useReceivedMapSharesState` | `{ (): ReceivedMapShareState[]; <T>(selector: (state: ReceivedMapShareState[]) => T): T; }` |

### useReceivedMapSharesState

| Function | Type |
| ---------- | ---------- |
| `useReceivedMapSharesState` | `{ (): ReceivedMapShareState[]; <T>(selector: (state: ReceivedMapShareState[]) => T): T; }` |

### useSentMapSharesActions

| Function | Type |
| ---------- | ---------- |
| `useSentMapSharesActions` | `() => { createAndSend({ receiverDeviceId, mapId, }: CreateAndSendMapShareOptions): Promise<MapShareState>; cancel({ shareId }: CancelMapShareOptions): Promise<...>; }` |

### useSentMapSharesState

| Function | Type |
| ---------- | ---------- |
| `useSentMapSharesState` | `<T>(selector?: ((state: MapShareState[]) => T) or undefined) => T` |

### createMapServerApi

Utility function to create a MapServerApi instance.
Only exported for unit testing purposes.

| Function | Type |
| ---------- | ---------- |
| `createMapServerApi` | `({ getBaseUrl, fetch, }: MapServerApiOptions) => MapServerApi` |

Parameters:

* `opts.getBaseUrl`: A function that returns a promise that resolves to the base URL of the map server.
* `opts.fetch`: An optional custom fetch function to use for making requests to the map server. If not provided, the global `fetch` will be used.


### MapServerProvider

Create a context provider that holds a `MapServerFetch` function, which waits
for the map server to be ready before making requests.

| Function | Type |
| ---------- | ---------- |
| `MapServerProvider` | `({ children, getBaseUrl, fetch, queryClient, }: MapServerProviderProps) => Element` |

Parameters:

* `opts.children`: React children node
* `opts.getBaseUrl`: A function that returns a promise that resolves to the base URL of the map server.
* `opts.fetch`: An optional custom fetch function to use for making requests to the map server. If not provided, the global `fetch` will be used.


Examples:

```tsx
import { createServer } from '@comapeo/map-server'

const server = createServer()
const listenPromise = server.listen()

const getBaseUrl = async () => {
  const { localPort } = await listenPromise
  return new URL(`http://localhost:${localPort}/`)
}

const mapServerApi = createMapServerApi({ getBaseUrl })

function App() {
  return (
    <MapServerProvider mapServerApi={mapServerApi}>
      <MyApp />
    </MapServerProvider>
  )
}
```


### useMapServerApi

Internal hook to get the MapServerApi (instance of ky) from context.
Throws if used outside of MapServerProvider.

| Function | Type |
| ---------- | ---------- |
| `useMapServerApi` | `() => MapServerApi` |

### ComapeoCoreProvider

| Function | Type |
| ---------- | ---------- |
| `ComapeoCoreProvider` | `({ children, clientApi, getMapServerBaseUrl, fetch, queryClient, }: ComapeoCoreProviderProps) => Element` |

### useProjectSettings

Retrieve the project settings for a project.

| Function | Type |
| ---------- | ---------- |
| `useProjectSettings` | `({ projectId, }: { projectId: string; }) => Pick<UseSuspenseQueryResult<EditableProjectSettings>, "data" or "error" or "isRefetching">` |

Parameters:

* `opts.projectId`: Project public ID


Examples:

```tsx
function BasicExample() {
  const { data } = useProjectSettings({ projectId: '...' })

  console.log(data.name)
}
```


### useSingleProject

Retrieve a project API instance for a project.

This is mostly used internally by the other hooks and should only be used if certain project APIs are not exposed via the hooks.

| Function | Type |
| ---------- | ---------- |
| `useSingleProject` | `({ projectId, }: { projectId: string; }) => Pick<UseSuspenseQueryResult<ClientApi<MapeoProject>>, "data" or "error" or "isRefetching">` |

Parameters:

* `opts.projectId`: Project public ID


Examples:

```tsx
function BasicExample() {
  const { data } = useSingleProject({ projectId: '...' })
}
```


### useManyProjects

Retrieve project information for each project that exists.

| Function | Type |
| ---------- | ---------- |
| `useManyProjects` | `() => Pick<UseSuspenseQueryResult<ListedProject[]>, "data" or "error" or "isRefetching">` |

Examples:

```tsx
function BasicExample() {
  const { data } = useManyProjects()

  console.log(data.map(project => project.name))
}
```


### useSingleMember

Retrieve a single member of a project.

| Function | Type |
| ---------- | ---------- |
| `useSingleMember` | `({ projectId, deviceId, }: { projectId: string; deviceId: string; }) => Pick<UseSuspenseQueryResult<MemberInfo>, "data" or "error" or "isRefetching">` |

Parameters:

* `opts.projectId`: Project public ID
* `opts.projectId`: Device ID of interest


Examples:

```tsx
function BasicExample() {
  const { data } = useSingleMember({ projectId: '...', deviceId: '...' })

  console.log(data.role)
}
```


### useManyMembers

Retrieve all members of a project.

| Function | Type |
| ---------- | ---------- |
| `useManyMembers` | `<T extends boolean>({ projectId, includeLeft, }: { projectId: string; includeLeft?: T or undefined; }) => Pick<UseSuspenseQueryResult<T extends true ? MemberInfo[] : ActiveMemberInfo[]>, "data" or ... 1 more ... or "isRefetching">` |

Parameters:

* `opts.projectId`: Project public ID


Examples:

```tsx
function BasicExample() {
  const activeMembers1 = useManyMembers({ projectId: '...' })
  const activeMembers2 = useManyMembers({ projectId: '...', includeLeft: false })

  const allMembers = useManyMembers({ projectId: '...', includeLeft: true })
}
```


### useIconUrl

Retrieve a URL that points to icon resources served by the embedded HTTP server.

_TODO: Explain bitmap opts vs svg opts_

| Function | Type |
| ---------- | ---------- |
| `useIconUrl` | `({ projectId, iconId, ...mimeBasedOpts }: { projectId: string; iconId: string; } and (BitmapOpts or SvgOpts)) => { data: string; error: Error or null; isRefetching: boolean; }` |

Parameters:

* `opts.projectId`: Project public ID
* `opts.iconId`: Icon ID of interest
* `opts.mimeType`: MIME type of desired resource
* `opts.pixelDensity`: Pixel density resource (only applicable when `mimeType` is `'image/png'`)
* `opts.size`: Size of desired resource


Examples:

```tsx
function PngExample() {
  const { data } = useIconUrl({
    projectId: '...',
    iconId: '...',
    mimeType: 'image/png',
    pixelDensity: 1,
    size: 'medium'
  })
}
```

```tsx
function SvgExample() {
  const { data } = useIconUrl({
    projectId: '...',
    iconId: '...',
    mimeType: 'image/svg',
    size: 'medium'
  })
}
```


### useAttachmentUrl

Retrieve a URL that points to a desired blob resource.

_TODO: Explain BlobId in more depth_

| Function | Type |
| ---------- | ---------- |
| `useAttachmentUrl` | `({ projectId, blobId, }: { projectId: string; blobId: BlobId; }) => { data: string; error: Error or null; isRefetching: boolean; }` |

Parameters:

* `opts.projectId`: Project public Id
* `opts.blobId`: Blob ID of the desired resource


Examples:

```tsx
function PhotoExample() {
  const { data } = useAttachmentUrl({
    projectId: '...',
    blobId: {
      type: 'photo',
      variant: 'thumbnail',
      name: '...',
      driveId: '...',
    }
  })
}
```

```tsx
function AudioExample() {
  const { data } = useAttachmentUrl({
    projectId: '...',
    blobId: {
      type: 'audio',
      variant: 'original',
      name: '...',
      driveId: '...',
    }
  })
}
```

```tsx
function VideoExample() {
  const { data } = useAttachmentUrl({
    projectId: '...',
    blobId: {
      type: 'video',
      variant: 'original',
      name: '...',
      driveId: '...',
    }
  })
}
```


### useDocumentCreatedBy

Retrieve the device ID that created a document.

| Function | Type |
| ---------- | ---------- |
| `useDocumentCreatedBy` | `({ projectId, originalVersionId, }: { projectId: string; originalVersionId: string; }) => { data: string; error: Error or null; isRefetching: boolean; }` |

Parameters:

* `opts.projectId`: Project public ID
* `opts.originalVersionId`: Version ID of document


Examples:

```tsx
function BasicExample() {
  const { data } = useDocumentCreatedBy({
    projectId: '...',
    originalVersionId: '...',
  })
}
```


### useOwnRoleInProject

Get the role for the current device in a specified project.
This is a more convenient alternative to using the `useOwnDeviceInfo` and `useManyMembers` hooks.

| Function | Type |
| ---------- | ---------- |
| `useOwnRoleInProject` | `({ projectId, }: { projectId: string; }) => Pick<UseSuspenseQueryResult<Role and { reason: string or undefined; }>, "data" or "error" or "isRefetching">` |

Parameters:

* `opts.projectId`: Project public ID


Examples:

```tsx
function BasicExample() {
  const { data } = useOwnRoleInProject({
    projectId: '...',
  })
}
```


### useAddServerPeer

| Function | Type |
| ---------- | ---------- |
| `useAddServerPeer` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, { baseUrl: string; dangerouslyAllowInsecureConnections?: boolean or undefined; }, unknown>, { ...; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useRemoveServerPeer

| Function | Type |
| ---------- | ---------- |
| `useRemoveServerPeer` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, { serverDeviceId: string; dangerouslyAllowInsecureConnections?: boolean or undefined; }, unknown>, { ...; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useCreateProject

Create a new project.

| Function | Type |
| ---------- | ---------- |
| `useCreateProject` | `() => Pick<Override<MutationObserverIdleResult<string, Error, { name?: string or undefined; configPath?: string or undefined; projectColor?: string or undefined; projectDescription?: string or undefined; } or undefined, unknown>, { ...; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pi...` |

### useLeaveProject

Leave an existing project.

| Function | Type |
| ---------- | ---------- |
| `useLeaveProject` | `() => Pick<Override<MutationObserverIdleResult<void, Error, { projectId: string; }, unknown>, { mutate: UseMutateFunction<void, Error, { projectId: string; }, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useImportProjectCategories

Update the categories of a project using an external file.

| Function | Type |
| ---------- | ---------- |
| `useImportProjectCategories` | `({ projectId, }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, { filePath: string; }, unknown>, { mutate: UseMutateFunction<void, Error, { ...; }, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Parameters:

* `opts.projectId`: Public ID of the project to apply changes to.


### useImportProjectConfig

Update the configuration of a project using an external file.

| Function | Type |
| ---------- | ---------- |
| `useImportProjectConfig` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<Error[], Error, { configPath: string; }, unknown>, { mutate: UseMutateFunction<Error[], Error, { ...; }, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Parameters:

* `opts.projectId`: Public ID of the project to apply changes to.


### useUpdateProjectSettings

Update the settings of a project.

| Function | Type |
| ---------- | ---------- |
| `useUpdateProjectSettings` | `({ projectId, }: { projectId: string; }) => FilteredMutationResult<UseMutationResult<EditableProjectSettings, Error, Partial<EditableProjectSettings>>>` |

Parameters:

* `opts.projectId`: Public ID of the project to apply changes to.


### useChangeMemberRole

Change a project member's role.

| Function | Type |
| ---------- | ---------- |
| `useChangeMemberRole` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, { deviceId: string; roleId: "f7c150f5a3a9a855" or "012fd2d431c0bf60" or "9e6d29263cba36c9"; }, unknown>, { ...; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Parameters:

* `opts.projectId`: Project public ID


Examples:

```tsx
function BasicExample() {
  const { mutate } = useChangeMemberRole({ projectId: '...' })
  // Use one of: COORDINATOR_ROLE_ID, MEMBER_ROLE_ID, BLOCKED_ROLE_ID
  mutate({ deviceId: '...', roleId: COORDINATOR_ROLE_ID })
}
```


### useRemoveMember

Remove a member from a project, providing an optional reason for removal.

Do NOT use this for removing your own device from a project. Use `useLeaveProject` instead.

| Function | Type |
| ---------- | ---------- |
| `useRemoveMember` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, { deviceId: string; reason?: string or undefined; }, unknown>, { mutate: UseMutateFunction<...>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Parameters:

* `opts.projectId`: Project public ID


Examples:

```tsx
function BasicExample() {
  const { mutate } = useRemoveMember({ projectId: '...' })
  mutate({
    deviceId: '...',
    // Optional
    reason: '...',
  })
}
```


### useProjectOwnRoleChangeListener

Set up listener for changes to your own role in a project.
It is necessary to use this if you want the project role-related read hooks to update
based on role change events that are received in the background.

| Function | Type |
| ---------- | ---------- |
| `useProjectOwnRoleChangeListener` | `({ projectId, }: { projectId: string; }) => void` |

Examples:

```tsx
function ListenerComponent({ projectId }: { projectId: string }) {
  // Set up the listener
  useProjectOwnRoleChangeListener({ projectId })
}

// Handle role change events separately
function EventHandlerComponent() {
  const { data: projectApi } = useSingleProject({ projectId })

  useEffect(() => {
    function handleRoleChangeEvent(event) {
	     // Do something with event...
    }

    projectApi.addListener('own-role-change', handleRoleChangeEvent)

    return () => {
      projectApi.removeListener('own-role-change', handleRoleChangeEvent)
    }
  }, [projectApi])
}
```


### useCreateBlob

Create a blob for a project.

| Function | Type |
| ---------- | ---------- |
| `useCreateBlob` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<{ driveId: string; name: string; type: "photo" or "audio" or "video"; hash: string; }, Error, { original: string; preview?: string or undefined; thumbnail?: string or undefined; metadata: Metadata; }, unknown>, { ...; }> and { ...; }, "err...` |

Parameters:

* `opts.projectId`: Public project ID of project to apply to changes to.


### useSyncState

Hook to subscribe to the current sync state.

Creates a global singleton for each project, to minimize traffic over IPC -
this hook can safely be used in more than one place without attaching
additional listeners across the IPC channel.

| Function | Type |
| ---------- | ---------- |
| `useSyncState` | `({ projectId, }: { projectId: string; }) => State or null` |

Parameters:

* `opts.projectId`: Project public ID


Examples:

```ts
function Example() {
    const syncState = useSyncState({ projectId });

    if (!syncState) {
        // Sync information hasn't been loaded yet
    }

    // Actual info about sync state is available...
}
```


### useDataSyncProgress

Provides the progress of data sync for sync-enabled connected peers

| Function | Type |
| ---------- | ---------- |
| `useDataSyncProgress` | `({ projectId, }: { projectId: string; }) => number or null` |

Returns:

`null` if no sync state events have been received. Otherwise returns a value between 0 and 1 (inclusive)

### useStartSync

| Function | Type |
| ---------- | ---------- |
| `useStartSync` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, { autostopDataSyncAfter: number or null; } or undefined, unknown>, { ...; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useStopSync

| Function | Type |
| ---------- | ---------- |
| `useStopSync` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, void, unknown>, { mutate: UseMutateFunction<void, Error, void, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useConnectSyncServers

| Function | Type |
| ---------- | ---------- |
| `useConnectSyncServers` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, void, unknown>, { mutate: UseMutateFunction<void, Error, void, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useDisconnectSyncServers

| Function | Type |
| ---------- | ---------- |
| `useDisconnectSyncServers` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, void, unknown>, { mutate: UseMutateFunction<void, Error, void, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useSetAutostopDataSyncTimeout

| Function | Type |
| ---------- | ---------- |
| `useSetAutostopDataSyncTimeout` | `({ projectId, }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, { after: number or null; }, unknown>, { mutate: UseMutateFunction<void, Error, { ...; }, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useExportGeoJSON

Creates a GeoJson file with all the observations and/or tracks in the project.

| Function | Type |
| ---------- | ---------- |
| `useExportGeoJSON` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<string, Error, { path: string; exportOptions: { observations?: boolean or undefined; tracks?: boolean or undefined; lang?: string or undefined; }; }, unknown>, { ...; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> ...` |

Parameters:

* `opts.projectId`: Public ID of the project to apply changes to.


### useExportZipFile

Creates a zip file containing a GeoJson file with all the observations and/or tracks in the project and all associated attachments (photos and audio).

| Function | Type |
| ---------- | ---------- |
| `useExportZipFile` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<string, Error, { path: string; exportOptions: { observations?: boolean or undefined; tracks?: boolean or undefined; lang?: string or undefined; attachments?: boolean or undefined; }; }, unknown>, { ...; }> and { ...; }, "error" or ... 3 mor...` |

Parameters:

* `opts.projectId`: Public ID of the project to apply changes to.


### useManyInviteLinks

Get all active invite links.

| Function | Type |
| ---------- | ---------- |
| `useManyInviteLinks` | `({ projectId, }: { projectId: string; }) => Pick<UseSuspenseQueryResult<InviteLink[]>, "data" or "error" or "isRefetching">` |

### useCreateInviteLink

Create an invite link for a project.

| Function | Type |
| ---------- | ---------- |
| `useCreateInviteLink` | `() => FilteredMutationResult<UseMutationResult<string, Error, { projectId: string; } and Omit<InviteOptions, "__testOnlyInviteId">>>` |

### useCancelInviteLink

Cancel a created invite link or all invite links for a project. If `inviteId` is not specified,
all invite links are cancelled.

| Function | Type |
| ---------- | ---------- |
| `useCancelInviteLink` | `() => Pick<Override<MutationObserverIdleResult<void, Error, { projectId: string; inviteId?: string or undefined; }, unknown>, { mutate: UseMutateFunction<void, Error, { ...; }, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Examples:

ts```
function Example() {
  const cancelInviteLink = useCancelInviteLink()

  // Cancel a specific invite link
  cancelInviteLink.mutate({ projectId: '...', inviteId: '...' })

  // Cancel all invite links
  cancelInviteLink.mutate({ projectId: '...' })
}
```


### useAcceptInviteLinkRequest

Accept an invite link join request for a project.

| Function | Type |
| ---------- | ---------- |
| `useAcceptInviteLinkRequest` | `() => FilteredMutationResult<UseMutationResult<InviteDecision, Error, { projectId: string; inviteId: string; deviceId: string; }>>` |

### useDenyInviteLinkRequest

Deny an invite link join request for a project.

| Function | Type |
| ---------- | ---------- |
| `useDenyInviteLinkRequest` | `() => FilteredMutationResult<UseMutationResult<void, Error, { projectId: string; inviteId: string; deviceId: string; }>>` |

### useSingleDocByDocId

Retrieve a single document from the database based on the document's document ID.

Triggers the closest error boundary if the document cannot be found

| Function | Type |
| ---------- | ---------- |
| `useSingleDocByDocId` | `<D extends WriteableDocumentType>({ projectId, docType, docId, lang, }: { projectId: string; docType: D; docId: string; lang?: string or undefined; }) => Pick<UseSuspenseQueryResult<NonNullable<Awaited<ReturnType<ClientApi<MapeoProject>[D]["getByDocId"]>>>>, "data" or ... 1 more ... or "isRefetching">` |

Parameters:

* `opts.projectId`: Project public ID
* `opts.docType`: Document type of interest
* `opts.docId`: Document ID
* `opts.lang`: Language to translate the document into


Examples:

```tsx
function SingleDocumentByDocIdExample() {
  const { data } = useSingleDocByDocId({
    projectId: '...',
    docType: 'observation',
    docId: '...',
  })

  console.log(data.schemaName) // logs 'observation'
}
```


### useSingleDocByVersionId

Retrieve a single document from the database based on the document's version ID.

Triggers the closest error boundary if the document cannot be found.

| Function | Type |
| ---------- | ---------- |
| `useSingleDocByVersionId` | `<D extends WriteableDocumentType>({ projectId, docType, versionId, lang, }: { projectId: string; docType: D; versionId: string; lang?: string or undefined; }) => Pick<UseSuspenseQueryResult<Awaited<ReturnType<ClientApi<MapeoProject>[D]["getByVersionId"]>>>, "data" or ... 1 more ... or "isRefetching">` |

Parameters:

* `opts.projectId`: Project public ID
* `opts.docType`: Document type of interest
* `opts.versionId`: Document's version ID
* `opts.lang`: Language to translate the document into

*


Examples:

```tsx
function SingleDocumentByVersionIdExample() {
  const { data } = useSingleDocByVersionId({
    projectId: '...',
    docType: 'observation',
    docId: '...',
  })

  console.log(data.schemaName) // logs 'observation'
}
```


### useManyDocs

Retrieve all documents of a specific `docType`.

| Function | Type |
| ---------- | ---------- |
| `useManyDocs` | `<D extends WriteableDocumentType>({ projectId, docType, includeDeleted, lang, }: { projectId: string; docType: D; includeDeleted?: boolean or undefined; lang?: string or undefined; }) => Pick<UseSuspenseQueryResult<Awaited<ReturnType<ClientApi<MapeoProject>[D]["getMany"]>>>, "data" or ... 1 more ... or "isRefetching">` |

Parameters:

* `opts.projectId`: Project public ID
* `opts.docType`: Document type of interest
* `opts.includeDeleted`: Include documents that have been marked as deleted
* `opts.lang`: Language to translate the documents into


Examples:

```tsx
function BasicExample() {
  const { data } = useManyDocs({
    projectId: '...',
    docType: 'observations',
  })
}
```

```tsx
function useAllObservations(opts) {
  return useManyDocs({
    ...opts,
    docType: 'observations',
  })
}

function useAllPresets(opts) {
  return useManyDocs({
    ...opts,
    docType: 'presets',
  })
}
```


### useCreateDocument

Create a document for a project.

| Function | Type |
| ---------- | ---------- |
| `useCreateDocument` | `<D extends WriteableDocumentType>({ docType, projectId, }: { docType: D; projectId: string; }) => FilteredMutationResult<UseMutationResult<Awaited<ReturnType<ClientApi<MapeoProject>[D]["create"]>>, Error, { ...; }>>` |

Parameters:

* `opts.docType`: Document type to create.
* `opts.projectId`: Public ID of project to create document for.


### useUpdateDocument

Update a document within a project.

| Function | Type |
| ---------- | ---------- |
| `useUpdateDocument` | `<D extends WriteableDocumentType>({ docType, projectId, }: { docType: D; projectId: string; }) => FilteredMutationResult<UseMutationResult<Awaited<ReturnType<ClientApi<MapeoProject>[D]["update"]>>, Error, { ...; }>>` |

Parameters:

* `opts.docType`: Document type to update.
* `opts.projectId`: Public ID of project document belongs to.


### useDeleteDocument

Delete a document within a project.

| Function | Type |
| ---------- | ---------- |
| `useDeleteDocument` | `<D extends WriteableDocumentType>({ docType, projectId, }: { docType: D; projectId: string; }) => FilteredMutationResult<UseMutationResult<Awaited<ReturnType<ClientApi<MapeoProject>[D]["delete"]>>, Error, { ...; }>>` |

Parameters:

* `opts.docType`: Document type to delete.
* `opts.projectId`: Public ID of project document belongs to.


### usePresetsSelection

Retrieve presets for category selection, ordered by project settings.

Returns presets in the order defined by `projectSettings.defaultPresets` for the
specified data type. Falls back to alphabetical order (by preset name) if no defaults are configured.

| Function | Type |
| ---------- | ---------- |
| `usePresetsSelection` | `({ projectId, dataType, lang, }: { projectId: string; dataType: "track" or "observation"; lang?: string or undefined; }) => { schemaName: "preset"; name: string; geometry: ("point" or "line" or "vertex" or "area" or "relation")[]; ... 13 more ...; deleted: boolean; }[]` |

Parameters:

* `opts.projectId`: Project public ID
* `opts.dataType`: Type of data being created ('observation' or 'track')
* `opts.lang`: Language to translate presets into


Examples:

```tsx
function ObservationCategoryChooser() {
  const presets = usePresetsSelection({
    projectId: '...',
    dataType: 'observation',
  })
}
```

```tsx
function TrackCategoryChooser() {
  const presets = usePresetsSelection({
    projectId: '...',
    dataType: 'track',
  })
}
```


### useManyInvites

Get all invites that the device has received.

| Function | Type |
| ---------- | ---------- |
| `useManyInvites` | `() => Pick<UseSuspenseQueryResult<Invite[]>, "data" or "error" or "isRefetching">` |

Examples:

```ts
function Example() {
  const { data } = useManyInvites()
}
```


### useSingleInvite

Get a single invite based on its ID.

| Function | Type |
| ---------- | ---------- |
| `useSingleInvite` | `({ inviteId, }: { inviteId: string; }) => Pick<UseSuspenseQueryResult<Invite>, "data" or "error" or "isRefetching">` |

Parameters:

* `opts.inviteId`: ID of invite


Examples:

```ts
function Example() {
  const { data } = useSingleInvite({ inviteId: '...' })
}
```


### useAcceptInvite

Accept an invite that has been received.

| Function | Type |
| ---------- | ---------- |
| `useAcceptInvite` | `() => Pick<Override<MutationObserverIdleResult<string, Error, { inviteId: string; }, unknown>, { mutate: UseMutateFunction<string, Error, { inviteId: string; }, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useRejectInvite

Reject an invite that has been received.

| Function | Type |
| ---------- | ---------- |
| `useRejectInvite` | `() => Pick<Override<MutationObserverIdleResult<void, Error, { inviteId: string; }, unknown>, { mutate: UseMutateFunction<void, Error, { inviteId: string; }, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useSendInvite

Send an invite for a project.

| Function | Type |
| ---------- | ---------- |
| `useSendInvite` | `({ projectId, }: { projectId: string; }) => FilteredMutationResult<UseMutationResult<InviteDecision, Error, { deviceId: string; roleDescription?: string or undefined; roleId: "f7c150f5a3a9a855" or "012fd2d431c0bf60" or "9e6d29263cba36c9"; roleName?: string or undefined; }>>` |

Parameters:

* `opts.projectId`: Public ID of project to send the invite on behalf of.


### useRequestCancelInvite

Request a cancellation of an invite sent to another device.

| Function | Type |
| ---------- | ---------- |
| `useRequestCancelInvite` | `({ projectId }: { projectId: string; }) => Pick<Override<MutationObserverIdleResult<void, Error, { deviceId: string; }, unknown>, { mutate: UseMutateFunction<void, Error, { ...; }, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Parameters:

* `opts.projectId`: Public ID of project to request the invite cancellation for.


### useManyJoinRequests

Get all active join requests.

| Function | Type |
| ---------- | ---------- |
| `useManyJoinRequests` | `() => Pick<UseSuspenseQueryResult<JoinRequest[]>, "data" or "error" or "isRefetching">` |

### useSingleJoinRequest

Get an active join request.

If the join request is no longer active after using this hook, the read result
will update such that the `error` field is populated with the relevant error from core.

| Function | Type |
| ---------- | ---------- |
| `useSingleJoinRequest` | `({ inviteId, }: { inviteId: string; }) => Pick<UseSuspenseQueryResult<JoinRequest>, "data" or "error" or "isRefetching">` |

Parameters:

* `opts.inviteId`: ID of relevant invite.


Examples:

```ts
import { getErrorCode } from '@comapeo/core/errors.js'

function ErrorExample({ inviteId }) {
  const joinRequestQuery = useSingleJoinRequest({ inviteId })

  if (joinRequestQuery.error) {
    const comapeoErrorCode = getErrorCode(joinRequestQuery.error)

    // Match error code with errors from


### useCreateJoinRequest

Create a join request for a received invite.

| Function | Type |
| ---------- | ---------- |
| `useCreateJoinRequest` | `() => FilteredMutationResult<UseMutationResult<JoinRequest, Error, { url: string; timeout?: number or undefined; }>>` |

### useCancelJoinRequest

Cancel a join request that has been created for a received invite.

| Function | Type |
| ---------- | ---------- |
| `useCancelJoinRequest` | `() => FilteredMutationResult<UseMutationResult<void, Error, { inviteId: string; }>>` |

### useMapStyleUrl

Get a URL that points to a StyleJSON resource served by the embedded HTTP server.

| Function | Type |
| ---------- | ---------- |
| `useMapStyleUrl` | `() => { data: string; error: Error or null; isRefetching: boolean; }` |

Examples:

```tsx
function ExampleWithoutRefreshToken() {
  const { data, isRefetching } = useMapStyleUrl()

  console.log(data) // logs something like 'http://127.0.0.1:...'
}
```


### useImportCustomMapFile

Import a custom SMP map file, replacing any existing custom map. The mutation
resolves once the file is successfully uploaded and processed by the server.
If the file has an `upload` method (e.g. an expo-file-system `File`), it is
used for the upload so that the file is streamed from disk rather than read
into memory.

| Function | Type |
| ---------- | ---------- |
| `useImportCustomMapFile` | `() => Pick<Override<MutationObserverIdleResult<Response, Error, { file: File or ExpoFileDuckType; }, unknown>, { mutate: UseMutateFunction<...>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Examples:

```tsx
function MapImportExample() {
  const { mutate: importMap } = useImportCustomMapFile()

}
```


### useRemoveCustomMapFile

| Function | Type |
| ---------- | ---------- |
| `useRemoveCustomMapFile` | `() => Pick<Override<MutationObserverIdleResult<Response, Error, void, unknown>, { mutate: UseMutateFunction<Response, Error, void, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

### useGetCustomMapInfo

Get the map info for the custom map.

Note that this is _not_ a suspenseful hook. The different read states should be explicitly handled at usage.

| Function | Type |
| ---------- | ---------- |
| `useGetCustomMapInfo` | `() => Pick<QueryObserverRefetchErrorResult<{ name: string; size: number; created: number; }, Error>, "data" or "error" or "status" or "isRefetching"> or ... 4 more ... or Pick<...>` |

Examples:

```tsx
import { getErrorCode } from '@comapeo/core-react'

function Example() {
  const mapInfo = useGetCustomMapInfo()

  if (mapInfo.status === 'pending') {
    // handle pending...
  }

  if (mapInfo.status === 'error') {
    if (getErrorCode(mapInfo.error) === 'MAP_NOT_FOUND') {
      // handle not found error...
    } else {
      // handle all other errors...
    }
  }

  // Handle success state...
  console.log(mapInfo.data)
}
```


### useManyReceivedMapShares

Get all map shares that the device has received. Automatically updates when
new shares arrive or share states change.

IMPORTANT: This hook will not trigger a re-render when download progress
updates, only when the status changes. This is to avoid excessive re-renders
during downloads. Use `useSingleReceivedMapShare` to get real-time updates on
a specific share, including download progress.

| Function | Type |
| ---------- | ---------- |
| `useManyReceivedMapShares` | `() => ReceivedMapShareState[]` |

Examples:

```tsx
function MapSharesList() {
  const shares = useManyReceivedMapShares()

  return shares.map(share => (
    <div key={share.shareId}>
      {share.mapName} from {share.senderDeviceName} - {share.state}
    </div>
  ))
}
```


### useSingleReceivedMapShare

Get a single received map share based on its shareId.

| Function | Type |
| ---------- | ---------- |
| `useSingleReceivedMapShare` | `({ shareId }: { shareId: string; }) => ReceivedMapShareState` |

Parameters:

* `opts.shareId`: ID of the map share


Examples:

```tsx
function MapShareDetail({ shareId }: { shareId: string }) {
  const share = useSingleReceivedMapShare({ shareId })

  return <div>{share.mapName} - {share.state}</div>
}
```


### useDownloadReceivedMapShare

Accept and download a map share that has been received. The mutate promise
resolves once the map _starts_ downloading, before it finishes downloading.
Use `useManyReceivedMapShares` or `useSingleReceivedMapShare` to track
download progress and final status.

If the sender canceled the share before the receiver calls this, the
mutation will still resolve (the download starts), but the share status will
end up as `'canceled'` rather than `'completed'`. This is the only way the
receiver discovers that a share has been canceled — check `share.status`
after the download settles.

| Function | Type |
| ---------- | ---------- |
| `useDownloadReceivedMapShare` | `() => Pick<Override<MutationObserverIdleResult<void, Error, DownloadMapShareOptions, unknown>, { mutate: UseMutateFunction<void, Error, DownloadMapShareOptions, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Examples:

```tsx
function AcceptButton({ shareId }: { shareId: string }) {
  const { mutate: accept } = useDownloadReceivedMapShare()

  return <button onClick={() => accept({ shareId })}>Accept</button>
}
```


### useDeclineReceivedMapShare

Decline a map share that has been received. Notifies the sender that the
share was declined. The share status is only updated to `'declined'` after
the server confirms the decline — there is no optimistic update.

If the sender canceled the share before the decline reaches the server, the
share status will transition to `'canceled'` (not `'error'`) and the
mutation will throw a `MapShareCanceledError`.

| Function | Type |
| ---------- | ---------- |
| `useDeclineReceivedMapShare` | `() => Pick<Override<MutationObserverIdleResult<void, Error, DeclineMapShareOptions, unknown>, { mutate: UseMutateFunction<void, Error, DeclineMapShareOptions, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Examples:

```tsx
import { DeclineReason } from '@comapeo/core-react'
function DeclineButton({ shareId }: { shareId: string }) {
  const { mutate: decline } = useDeclineReceivedMapShare()

  return (
    <button onClick={() => decline({ shareId, reason: DeclineReason.user_rejected })}>
      Decline
    </button>
  )
}
```


### useAbortReceivedMapShareDownload

Abort an in-progress map share download.

| Function | Type |
| ---------- | ---------- |
| `useAbortReceivedMapShareDownload` | `() => Pick<Override<MutationObserverIdleResult<void, Error, AbortMapShareOptions, unknown>, { mutate: UseMutateFunction<void, Error, AbortMapShareOptions, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Examples:

```tsx
function AbortButton({ shareId }: { shareId: string }) {
  const { mutate: abort } = useAbortReceivedMapShareDownload()

  return <button onClick={() => abort({ shareId })}>Cancel Download</button>
}
```


### useSendMapShare

Share a map with a device. The mutation resolves immediately after sending
the share offer, without waiting for the recipient to accept or reject. The
mutation resolves with the created map share object, including its ID, which
can be used to track the share status with `useSingleSentMapShare`.

| Function | Type |
| ---------- | ---------- |
| `useSendMapShare` | `() => Pick<Override<MutationObserverIdleResult<MapShareState, Error, CreateAndSendMapShareOptions, unknown>, { ...; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Examples:

```tsx
function SendMapButton({ projectId, deviceId }: { projectId: string; deviceId: string }) {
const { mutate: send } = useSendMapShare()

return (
	<button
		onClick={() =>
			send({ receiverDeviceId: deviceId, mapId: 'custom' }, {
                   onSuccess: (mapShare) => {
                       console.log('Share sent with id', mapShare.shareId)
                   }
             )
		}
	>
		Send Map
	</button>
)
}
```


### useCancelSentMapShare

Cancel a map share that was previously sent. If the recipient has not yet
started downloading the share, they will not be notified until they attempt
to accept the share and begin downloading it. If they are already downloading
the share, the download will be canceled before completion. If the download
is already complete, this action will throw an error.

| Function | Type |
| ---------- | ---------- |
| `useCancelSentMapShare` | `() => Pick<Override<MutationObserverIdleResult<void, Error, CancelMapShareOptions, unknown>, { mutate: UseMutateFunction<void, Error, CancelMapShareOptions, unknown>; }> and { ...; }, "error" or ... 3 more ... or "mutateAsync"> or Pick<...> or Pick<...> or Pick<...>` |

Parameters:

* `opts.projectId`: Public ID of project to request the map share cancellation for.


Examples:

```tsx
function CancelShareButton({ projectId, shareId }: { projectId: string; shareId: string }) {
  const { mutate: cancel } = useRequestCancelMapShare({ projectId })

  return <button onClick={() => cancel({ shareId })}>Cancel Share</button>
}
```


### useSingleSentMapShare

Track the status and progress of a sent map share. Returns the current state
of the share, updated in real-time. When the recipient starts downloading, or
if they decline the share, then the returned share will update.

| Function | Type |
| ---------- | ---------- |
| `useSingleSentMapShare` | `({ shareId, }: { shareId: string; }) => MapShareState` |

Parameters:

* `opts.shareId`: ID of the sent map share


Examples:

```tsx
function SentShareStatus({ shareId }: { shareId: string }) {
  const mapShare = useSingleSentMapShare({ shareId })

  return (<div>
		<div>Share status: {mapShare.status}</div>
   {mapShare.status === 'pending' && <div>Waiting for recipient to accept...</div>}
  	{mapShare.status === 'downloading' && (<div>Download in progress: {mapShare.downloadProgress}%</div>)}
  	{mapShare.status === 'declined' && <div>Share was declined by recipient</div>}
	  {mapShare.status === 'canceled' && <div>Share was canceled</div>}
  </div>)
}
```



## Constants

- [ClientApiContext](#clientapicontext)
- [ReceivedMapSharesContext](#receivedmapsharescontext)
- [SentMapSharesContext](#sentmapsharescontext)
- [MapServerContext](#mapservercontext)

### ClientApiContext

| Constant | Type |
| ---------- | ---------- |
| `ClientApiContext` | `Context<ComapeoCoreClientApi or null>` |

### ReceivedMapSharesContext

| Constant | Type |
| ---------- | ---------- |
| `ReceivedMapSharesContext` | `Context<{ subscribe: (listener: () => void) => () => boolean; getSnapshot: () => ReceivedMapShareState[]; actions: { download({ shareId }: DownloadMapShareOptions): Promise<...>; decline({ shareId, reason }: DeclineMapShareOptions): Promise<...>; abort({ shareId }: AbortMapShareOptions): Promise<...>; }; } or null>` |

### SentMapSharesContext

| Constant | Type |
| ---------- | ---------- |
| `SentMapSharesContext` | `Context<{ subscribe: (listener: () => void) => () => boolean; getSnapshot: () => MapShareState[]; actions: { createAndSend({ receiverDeviceId, mapId, }: CreateAndSendMapShareOptions): Promise<...>; cancel({ shareId }: CancelMapShareOptions): Promise<...>; }; } or null>` |

### MapServerContext

| Constant | Type |
| ---------- | ---------- |
| `MapServerContext` | `Context<MapServerApi or null>` |



## Types

- [ClientApiProviderProps](#clientapiproviderprops)
- [CompatFile](#compatfile)
- [ExpoFileDuckType](#expofileducktype)
- [MapServerApiOptions](#mapserverapioptions)
- [MapServerApi](#mapserverapi)
- [MapServerProviderProps](#mapserverproviderprops)

### ClientApiProviderProps

| Type | Type |
| ---------- | ---------- |
| `ClientApiProviderProps` | `PropsWithChildren<{ clientApi: ComapeoCoreClientApi }>` |

### CompatFile

| Type | Type |
| ---------- | ---------- |
| `CompatFile` | `Omit<File, 'lastModified' or 'webkitRelativePath'>` |

### ExpoFileDuckType

| Type | Type |
| ---------- | ---------- |
| `ExpoFileDuckType` | `CompatFile and { exists: boolean }` |

### MapServerApiOptions

| Type | Type |
| ---------- | ---------- |
| `MapServerApiOptions` | `{ getBaseUrl(): Promise<URL or string> /** * We assume the passed fetch implementation will only accept a `string` as * input, not a `URL` or `Request`, because right now the expo/fetch * implementation will only accept a `string`. Adding this restriction will * catch potential issues if we try to pass a URL in our code. Can be relaxed * when https://github.com/expo/expo/issues/43193 is fixed upstream. */ fetch?(input: string, options?: RequestInit): Promise<Response> }` |

### MapServerApi

| Type | Type |
| ---------- | ---------- |
| `MapServerApi` | `ReturnType<typeof createHttp> and { createEventSource(options: EventSourceOptions): EventSourceClient getMapStyleJsonUrl(mapId: string): Promise<string> uploadFile( path: string, file: CompatFile or ExpoFileDuckType, options?: { headers?: Record<string, string> }, ): Promise<Response> }` |

### MapServerProviderProps

| Type | Type |
| ---------- | ---------- |
| `MapServerProviderProps` | `PropsWithChildren< MapServerApiOptions and { queryClient: QueryClient } >` |

